package com.experiencers.playeasy.view.callback;

public interface RetrofitCallback {
    void onSuccess(Object object);
}
